package pe.edu.cibertec.appweb5puntos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppWeb5puntosApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppWeb5puntosApplication.class, args);
	}

}
