package pe.edu.cibertec.appweb5puntos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppWeb5puntosApplicationTests {

	@Test
	void contextLoads() {
	}

}
